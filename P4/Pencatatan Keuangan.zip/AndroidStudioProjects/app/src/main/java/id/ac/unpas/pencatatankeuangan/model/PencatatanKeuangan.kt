package id.ac.unpas.pencatatankeuangan.model

data class PencatatanKeuangan(
    val tanggal: String,
    val keterangan: String,
    val pemasukan: String,
    val pengeluaran: String
)

