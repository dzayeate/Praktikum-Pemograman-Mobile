package id.ac.unpas.functionalcompose.model

data class SetoranSampah(
    val tanggal: String,
    val keterangan: String,
    val pemasukan: String
)
